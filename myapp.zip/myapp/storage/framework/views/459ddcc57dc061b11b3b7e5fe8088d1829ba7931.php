<!DOCTYPE html>
<html>
<head>
    <title>Create Orders</title>
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css">
</head>
<body>
<div class="container">

<nav class="navbar navbar-inverse">
    <div class="navbar-header">
        <a class="navbar-brand" href="<?php echo e(URL::to('api/orders')); ?>">Order Alert</a>
    </div>
    <ul class="nav navbar-nav">
        <li><a href="<?php echo e(URL::to('api/orders')); ?>">View All Orders</a></li>
        <li><a href="<?php echo e(URL::to('api/orders/create')); ?>">Create a Order</a>
    </ul>
</nav>

<h1>Create a Order</h1>

<?php echo e(Form::open(array('url' => 'orders'))); ?>


	 <div class="form-group">
        <?php echo e(Form::label('cust_id', 'Cust_id')); ?>

        <?php echo e(Form::text('cust_id', Input::old('cust_id'), array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('address', 'Address')); ?>

        <?php echo e(Form::text('address', Input::old('address'), array('class' => 'form-control'))); ?>

    </div>
	
	<div class="form-group">
        <?php echo e(Form::label('city', 'City')); ?>

        <?php echo e(Form::text('city', Input::old('city'), array('class' => 'form-control'))); ?>

    </div>
	
	<div class="form-group">
        <?php echo e(Form::label('phn_no', 'Phn_no')); ?>

        <?php echo e(Form::text('phn_no', Input::old('phn_no'), array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('items', 'Items')); ?>

        <?php echo e(Form::text('items', Input::old('items'), array('class' => 'form-control'))); ?>

    </div>
	
    <?php echo e(Form::submit('Create the Order!', array('class' => 'btn btn-primary'))); ?>


<?php echo e(Form::close()); ?>


</div>
</body>
</html>