<!DOCTYPE html>
<html>
<head>
    <title>Edit the Order</title>
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css">
</head>
<body>
<div class="container">

<nav class="navbar navbar-inverse">
    <div class="navbar-header">
        <a class="navbar-brand" href="<?php echo e(URL::to('api/orders')); ?>">Order Alert</a>
    </div>
    <ul class="nav navbar-nav">
        <li><a href="<?php echo e(URL::to('api/orders')); ?>">View All Orders</a></li>
        <li><a href="<?php echo e(URL::to('api/orders/create')); ?>">Create a Order</a>
    </ul>
</nav>

<h1>Edit Order</h1>


<?php echo e(Form::model($order, array('route' => array('orders.update', $order->cust_id), 'method' => 'PUT'))); ?>


    <div class="form-group">
        <?php echo e(Form::label('cust_id', 'Cust_id')); ?>

        <?php echo e(Form::text('cust_id', null, array('class' => 'form-control'))); ?>

    </div>
	
	<div class="form-group">
        <?php echo e(Form::label('address', 'Address')); ?>

        <?php echo e(Form::text('address', null, array('class' => 'form-control'))); ?>

    </div>
	
	<div class="form-group">
        <?php echo e(Form::label('city', 'City')); ?>

        <?php echo e(Form::text('city', null, array('class' => 'form-control'))); ?>

    </div>
	
	<div class="form-group">
        <?php echo e(Form::label('phn_no', 'Phn_no')); ?>

        <?php echo e(Form::text('phn_no', null, array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('items', 'Items')); ?>

        <?php echo e(Form::text('items', null, array('class' => 'form-control'))); ?>

    </div>

    <?php echo e(Form::submit('Edit the Order!', array('class' => 'btn btn-primary'))); ?>


<?php echo e(Form::close()); ?>


</div>
</body>
</html>