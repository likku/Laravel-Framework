<!DOCTYPE html>
<html>
<head>
    <title>Orders</title>
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css">
</head>
<body>
<div class="container">

<nav class="navbar navbar-inverse">
    <div class="navbar-header">
        <a class="navbar-brand" href="<?php echo e(URL::to('api/orders')); ?>">Order Alert</a>
    </div>
    <ul class="nav navbar-nav">
        <li><a href="<?php echo e(URL::to('api/orders')); ?>">View All Orders</a></li>
        <li><a href="<?php echo e(URL::to('api/orders/create')); ?>">Create a Order</a>
    </ul>
</nav>

<h1>All the Orders</h1>

<!-- will be used to show any messages -->
<?php if(Session::has('message')): ?>
    <div class="alert alert-info"><?php echo e(Session::get('message')); ?></div>
<?php endif; ?>

<table class="table table-striped table-bordered">
    <thead>
        <tr>
            <td>Customer ID</td>
            <td>Address</td>
            <td>City</td>
            <td>Phone no.</td>
            <td>Items</td>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($value->cust_id); ?></td>
            <td><?php echo e($value->address); ?></td>
            <td><?php echo e($value->city); ?></td>
            <td><?php echo e($value->phn_no); ?></td>
            <td><?php echo e($value->items); ?></td>

            <!-- we will also add show, edit, and delete buttons -->
            <td>
                <!-- show the order (uses the show method found at GET /orders/{id} -->
                <a class="btn btn-small btn-success" href="<?php echo e(URL::to('api/orders/' . $value->id)); ?>">Show this Order</a>

                <!-- edit this order (uses the edit method found at GET /orders/{id}/edit -->
                <a class="btn btn-small btn-info" href="<?php echo e(URL::to('api/orders/' . $value->id . '/edit')); ?>">Edit this Order</a>
				 
            </td>
			<td>
			<?php echo e(Form::open(array('url' => 'api/orders/' . $value->id, 'class' => 'pull-right'))); ?>

                    <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                    <?php echo e(Form::submit('Delete this Order', array('class' => 'btn btn-warning'))); ?>

                <?php echo e(Form::close()); ?>

			</td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

</div>
</body>
</html>