<!DOCTYPE html>
<html>
<head>
    <title>Show Orders</title>
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css">
</head>
<body>
<div class="container">

<nav class="navbar navbar-inverse">
    <div class="navbar-header">
        <a class="navbar-brand" href="<?php echo e(URL::to('api/orders')); ?>">Order Alert</a>
    </div>
    <ul class="nav navbar-nav">
        <li><a href="<?php echo e(URL::to('api/orders')); ?>">View All Orders</a></li>
        <li><a href="<?php echo e(URL::to('api/orders/create')); ?>">Create a Order</a>
    </ul>
</nav>

<h1>Showing Order</h1>

    <div class="jumbotron text-center">
        <p>
            <strong>Customer Id:</strong> <?php echo e($order->cust_id); ?><br>
            <strong>Address:</strong> <?php echo e($order->address); ?><br>
            <strong>City:</strong> <?php echo e($order->city); ?><br>
            <strong>Phn_no:</strong> <?php echo e($order->phn_no); ?><br>
            <strong>Items:</strong> <?php echo e($order->items); ?>

        </p>
    </div>

</div>
</body>
</html>